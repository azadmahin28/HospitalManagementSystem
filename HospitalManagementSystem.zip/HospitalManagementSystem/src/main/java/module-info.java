module com.mycompany.hospitalmanagementsystem {
    requires javafx.controls;
    exports com.mycompany.hospitalmanagementsystem;
}
