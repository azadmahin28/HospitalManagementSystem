/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;

/**
 *
 * @author Msi user
 */
public class Doctor {
    
    private String name;
    private String department;
    private String id;

    public Doctor(String name, String department, String id) {
        this.name = name;
        this.department = department;
        this.id = id;
    }

    public String getName() { return name; }
    public String getDepartment() { return department; }
    public String getId() { return id; }
}