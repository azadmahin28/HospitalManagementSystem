/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;

/**
 *
 * @author Msi user
 */
import java.time.LocalDate;
public class Record {
    
     private LocalDate date;
    private final double billAmount;

    public Record(LocalDate date, double billAmount) {
        this.billAmount = billAmount;
    }
    
}
