/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;

/**
 *
 * @author Msi user
 */
public class AdmittedPatient extends Patient {
       public AdmittedPatient(int id, String name, int age, String condition) { 
        super(id, name, age, condition); 
    }
    
    @Override
    public double calculateBill() { 
        return 5000.0; 
    }
}
    
    

