/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;

/**
 *
 * @author Msi user
 */
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.scene.control.cell.PropertyValueFactory;
import java.time.LocalDate;

public class HospitalSystemFX extends Application {
    
    private HospitalManager manager;
    private TableView<Patient> patientTable;
    private ObservableList<Patient> observablePatients;
    
    @Override
    public void start(Stage primaryStage) {
        manager = new HospitalManager();
        
        // Add sample data
        addSampleData();
        
        primaryStage.setTitle("Hospital Management System");
        
        // Create main layout
        VBox mainLayout = new VBox(10);
        mainLayout.setPadding(new Insets(10));
        
        // Create tabs
        TabPane tabPane = new TabPane();
        
        // Patients Tab
        Tab patientsTab = new Tab("Patients");
        patientsTab.setContent(createPatientsTab());
        patientsTab.setClosable(false);
        
        // Doctors Tab
        Tab doctorsTab = new Tab("Doctors");
        doctorsTab.setContent(createDoctorsTab());
        doctorsTab.setClosable(false);
        
        // Billing Tab
        Tab billingTab = new Tab("Billing");
        billingTab.setContent(createBillingTab());
        billingTab.setClosable(false);
        
        tabPane.getTabs().addAll(patientsTab, doctorsTab, billingTab);
        
        mainLayout.getChildren().add(tabPane);
        
        Scene scene = new Scene(mainLayout, 1000, 600);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    private VBox createPatientsTab() {
        VBox vbox = new VBox(10);
        vbox.setPadding(new Insets(10));
        
        // Create table
        patientTable = new TableView<>();
        
        TableColumn<Patient, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        idCol.setPrefWidth(50);
        
        TableColumn<Patient, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        nameCol.setPrefWidth(150);
        
        TableColumn<Patient, Integer> ageCol = new TableColumn<>("Age");
        ageCol.setCellValueFactory(new PropertyValueFactory<>("age"));
        ageCol.setPrefWidth(50);
        
        TableColumn<Patient, String> conditionCol = new TableColumn<>("Condition");
        conditionCol.setCellValueFactory(new PropertyValueFactory<>("condition"));
        conditionCol.setPrefWidth(150);
        
        TableColumn<Patient, String> typeCol = new TableColumn<>("Patient Type");
        typeCol.setCellValueFactory(cellData -> 
            new javafx.beans.property.SimpleStringProperty(cellData.getValue().getClass().getSimpleName()));
        typeCol.setPrefWidth(120);
        
        TableColumn<Patient, Double> billCol = new TableColumn<>("Bill Amount (BDT)");
        billCol.setCellValueFactory(cellData -> 
            new javafx.beans.property.SimpleDoubleProperty(cellData.getValue().calculateBill()).asObject());
        billCol.setPrefWidth(120);
        
        patientTable.getColumns().addAll(idCol, nameCol, ageCol, conditionCol, typeCol, billCol);
        
        observablePatients = FXCollections.observableArrayList(manager.getPatients());
        patientTable.setItems(observablePatients);
        patientTable.setPrefHeight(300);
        
        // Form for adding new patient
        GridPane formGrid = new GridPane();
        formGrid.setHgap(10);
        formGrid.setVgap(10);
        formGrid.setPadding(new Insets(10));
        formGrid.setStyle("-fx-border-color: lightgray; -fx-border-radius: 5;");
        
        TextField idField = new TextField();
        idField.setPromptText("ID");
        TextField nameField = new TextField();
        nameField.setPromptText("Name");
        TextField ageField = new TextField();
        ageField.setPromptText("Age");
        TextField conditionField = new TextField();
        conditionField.setPromptText("Condition");
        
        ComboBox<String> typeCombo = new ComboBox<>();
        typeCombo.getItems().addAll("GeneralPatient", "EmergencyPatient", "AdmittedPatient");
        typeCombo.setValue("GeneralPatient");
        
        Button addButton = new Button("Add Patient");
        addButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        addButton.setOnAction(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                String name = nameField.getText();
                int age = Integer.parseInt(ageField.getText());
                String condition = conditionField.getText();
                String type = typeCombo.getValue();
                
                Patient patient = null;
                switch(type) {
                    case "GeneralPatient":
                        patient = new GeneralPatient(id, name, age, condition);
                        break;
                    case "EmergencyPatient":
                        patient = new EmergencyPatient(id, name, age, condition);
                        break;
                    case "AdmittedPatient":
                        patient = new AdmittedPatient(id, name, age, condition);
                        break;
                }
                
                if(patient != null) {
                    manager.addPatient(patient);
                    observablePatients.add(patient);
                    
                    // Clear fields
                    idField.clear();
                    nameField.clear();
                    ageField.clear();
                    conditionField.clear();
                    
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Patient added successfully!");
                }
            } catch(NumberFormatException ex) {
                showAlert(Alert.AlertType.ERROR, "Error", "Please enter valid numbers for ID and Age!");
            }
        });
        
        Button deleteButton = new Button("Delete Selected");
        deleteButton.setStyle("-fx-background-color: #f44336; -fx-text-fill: white;");
        deleteButton.setOnAction(e -> {
            Patient selected = patientTable.getSelectionModel().getSelectedItem();
            if(selected != null) {
                manager.getPatients().remove(selected);
                observablePatients.remove(selected);
                showAlert(Alert.AlertType.INFORMATION, "Success", "Patient deleted successfully!");
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning", "Please select a patient to delete!");
            }
        });
        
        formGrid.add(new Label("ID:"), 0, 0);
        formGrid.add(idField, 1, 0);
        formGrid.add(new Label("Name:"), 2, 0);
        formGrid.add(nameField, 3, 0);
        formGrid.add(new Label("Age:"), 4, 0);
        formGrid.add(ageField, 5, 0);
        formGrid.add(new Label("Condition:"), 0, 1);
        formGrid.add(conditionField, 1, 1);
        formGrid.add(new Label("Patient Type:"), 2, 1);
        formGrid.add(typeCombo, 3, 1);
        formGrid.add(addButton, 4, 1);
        formGrid.add(deleteButton, 5, 1);
        
        vbox.getChildren().addAll(new Label("Patient List:"), patientTable, new Separator(), 
                                   new Label("Add New Patient:"), formGrid);
        
        return vbox;
    }
    
    private VBox createDoctorsTab() {
        VBox vbox = new VBox(10);
        vbox.setPadding(new Insets(10));
        
        // Create table for doctors
        TableView<Doctor> doctorTable = new TableView<>();
        
        TableColumn<Doctor, String> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        idCol.setPrefWidth(80);
        
        TableColumn<Doctor, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        nameCol.setPrefWidth(150);
        
        TableColumn<Doctor, String> deptCol = new TableColumn<>("Department");
        deptCol.setCellValueFactory(new PropertyValueFactory<>("department"));
        deptCol.setPrefWidth(150);
        
        doctorTable.getColumns().addAll(idCol, nameCol, deptCol);
        
        ObservableList<Doctor> observableDoctors = FXCollections.observableArrayList(manager.getDoctors());
        doctorTable.setItems(observableDoctors);
        doctorTable.setPrefHeight(300);
        
        // Form for adding new doctor
        GridPane formGrid = new GridPane();
        formGrid.setHgap(10);
        formGrid.setVgap(10);
        formGrid.setPadding(new Insets(10));
        formGrid.setStyle("-fx-border-color: lightgray; -fx-border-radius: 5;");
        
        TextField idField = new TextField();
        idField.setPromptText("Doctor ID");
        TextField nameField = new TextField();
        nameField.setPromptText("Name");
        TextField deptField = new TextField();
        deptField.setPromptText("Department");
        
        Button addButton = new Button("Add Doctor");
        addButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        addButton.setOnAction(e -> {
            String id = idField.getText();
            String name = nameField.getText();
            String dept = deptField.getText();
            
            if(!id.isEmpty() && !name.isEmpty() && !dept.isEmpty()) {
                Doctor doctor = new Doctor(name, dept, id);
                manager.addDoctor(doctor);
                observableDoctors.add(doctor);
                
                idField.clear();
                nameField.clear();
                deptField.clear();
                
                showAlert(Alert.AlertType.INFORMATION, "Success", "Doctor added successfully!");
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Please fill all fields!");
            }
        });
        
        formGrid.add(new Label("ID:"), 0, 0);
        formGrid.add(idField, 1, 0);
        formGrid.add(new Label("Name:"), 2, 0);
        formGrid.add(nameField, 3, 0);
        formGrid.add(new Label("Department:"), 4, 0);
        formGrid.add(deptField, 5, 0);
        formGrid.add(addButton, 6, 0);
        
        vbox.getChildren().addAll(new Label("Doctor List:"), doctorTable, new Separator(),
                                   new Label("Add New Doctor:"), formGrid);
        
        return vbox;
    }
    
    private VBox createBillingTab() {
        VBox vbox = new VBox(10);
        vbox.setPadding(new Insets(10));
        
        // ComboBox for patient selection
        Label selectLabel = new Label("Select Patient to View Bill:");
        ComboBox<Patient> patientCombo = new ComboBox<>();
        patientCombo.setItems(observablePatients);
        patientCombo.setPromptText("Select a patient");
        
        // Display area for bill
        TextArea billArea = new TextArea();
        billArea.setEditable(false);
        billArea.setPrefHeight(300);
        
        Button showBillButton = new Button("Show Bill");
        showBillButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white;");
        showBillButton.setOnAction(e -> {
            Patient selected = patientCombo.getValue();
            if(selected != null) {
                StringBuilder bill = new StringBuilder();
                bill.append("========== PATIENT BILL ==========\n");
                bill.append("Patient ID: ").append(selected.getId()).append("\n");
                bill.append("Patient Name: ").append(selected.getName()).append("\n");
                bill.append("Age: ").append(selected.getAge()).append("\n");
                bill.append("Condition: ").append(selected.getCondition()).append("\n");
                bill.append("Patient Type: ").append(selected.getClass().getSimpleName()).append("\n");
                bill.append("-----------------------------------\n");
                bill.append("Bill Amount: ").append(selected.calculateBill()).append(" BDT\n");
                bill.append("Date: ").append(LocalDate.now()).append("\n");
                bill.append("===================================\n");
                billArea.setText(bill.toString());
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning", "Please select a patient!");
            }
        });
        
        Button generateAllBillsButton = new Button("Generate All Bills Report");
        generateAllBillsButton.setStyle("-fx-background-color: #FF9800; -fx-text-fill: white;");
        generateAllBillsButton.setOnAction(e -> {
            StringBuilder report = new StringBuilder();
            report.append("========== HOSPITAL BILLING REPORT ==========\n");
            report.append("Date: ").append(LocalDate.now()).append("\n");
            report.append("=============================================\n\n");
            
            double total = 0;
            for(Patient p : manager.getPatients()) {
                double bill = p.calculateBill();
                report.append("Patient: ").append(p.getName()).append("\n");
                report.append("Type: ").append(p.getClass().getSimpleName()).append("\n");
                report.append("Condition: ").append(p.getCondition()).append("\n");
                report.append("Bill: ").append(bill).append(" BDT\n");
                report.append("---------------------------------------------\n");
                total += bill;
            }
            report.append("\nTOTAL REVENUE: ").append(total).append(" BDT\n");
            report.append("=============================================");
            billArea.setText(report.toString());
        });
        
        HBox buttonBox = new HBox(10);
        buttonBox.getChildren().addAll(showBillButton, generateAllBillsButton);
        
        vbox.getChildren().addAll(selectLabel, patientCombo, buttonBox, new Separator(), 
                                   new Label("Bill Details:"), billArea);
        
        return vbox;
    }
    
    private void addSampleData() {
        Doctor d1 = new Doctor("Dr. Hasan", "Cardiology", "D001");
        Doctor d2 = new Doctor("Dr. Ali", "Emergency", "D002");
        Doctor d3 = new Doctor("Dr. Fatema", "Pediatrics", "D003");
        manager.addDoctor(d1);
        manager.addDoctor(d2);
        manager.addDoctor(d3);
        
        Patient p1 = new GeneralPatient(1, "Rahim", 25, "Fever");
        Patient p2 = new EmergencyPatient(2, "Karim", 30, "Accident");
        Patient p3 = new AdmittedPatient(3, "Sakib", 40, "Surgery");
        Patient p4 = new GeneralPatient(4, "Maria", 35, "Common Cold");
        Patient p5 = new EmergencyPatient(5, "Jamal", 45, "Heart Attack");
        
        manager.addPatient(p1);
        manager.addPatient(p2);
        manager.addPatient(p3);
        manager.addPatient(p4);
        manager.addPatient(p5);
    }
    
    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}