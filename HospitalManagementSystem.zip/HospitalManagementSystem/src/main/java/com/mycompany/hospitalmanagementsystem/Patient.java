/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;

/**
 *
 * @author Msi user
 */
public abstract class Patient {
    protected int id;
    protected String name;
    protected int age;
    protected String condition;

    public Patient(int id, String name, int age, String condition) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.condition = condition;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getCondition() { return condition; }
    
    public abstract double calculateBill();
    
    public String getDetails() { 
        return id + "," + name + "," + age + "," + condition; 
    }
}