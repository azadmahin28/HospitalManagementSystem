/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;

/**
 *
 * @author Msi user
 */
import java.io.*;

public class FileHandler {
  
    public static void saveData(HospitalManager manager) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("patients.txt"))) {
            for (Patient p : manager.getPatients()) {
                writer.write(p.getDetails()); 
                writer.write("," + p.getClass().getSimpleName());
                writer.newLine();
            }
            System.out.println("Data saved!");
        } catch (IOException e) {
            System.out.println("Save error!");
        }
    }

    public static void loadData() {
        try (BufferedReader reader = new BufferedReader(new FileReader("patients.txt"))) {
            String line;
            System.out.println("\nLoaded Data:");
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("Load error!");
        } 
    }
    
   
// Add this method to your existing FileHandler class
public static String loadDataToString() {
    StringBuilder content = new StringBuilder();
    try (BufferedReader reader = new BufferedReader(new FileReader("patients.txt"))) {
        String line;
        while ((line = reader.readLine()) != null) {
            content.append(line).append("\n");
        }
        return content.toString();
    } catch (IOException e) {
        return null;
    }
}
}
