/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hospitalmanagementsystem;

/**
 *
 * @author Msi user
 */
import java.time.LocalDate;

public class Hospitalsystem {
    public static void main(String[] args) {
        HospitalManager manager = new HospitalManager();

        // Create doctors
        Doctor d1 = new Doctor("Dr. Hasan", "Cardiology", "0123");
        Doctor d2 = new Doctor("Dr. Ali", "Emergency", "0456");

        manager.addDoctor(d1);
        manager.addDoctor(d2);

        // Create patients
        Patient p1 = new GeneralPatient(1, "Rahim", 25, "Fever");
        Patient p2 = new EmergencyPatient(2, "Karim", 30, "Accident");
        Patient p3 = new AdmittedPatient(3, "Sakib", 40, "Surgery");

        manager.addPatient(p1);
        manager.addPatient(p2);
        manager.addPatient(p3);

        // Assign doctors
        manager.assignDoctor(0, 0);
        manager.assignDoctor(1, 1);
        manager.assignDoctor(2, 0);

        // Display patients
        System.out.println("\n--- Patient Bills ---");
        for (Patient p : manager.getPatients()) {
            double bill = p.calculateBill();
            Record r = new Record(LocalDate.now(), bill);
            System.out.println(p.getName() + " (Condition: " + p.getCondition() + ") - Bill Amount: " + bill + " BDT");
        }
        
        // Save and Load Data using FileHandler
        System.out.println("\n--- File Handling ---");
        FileHandler.saveData(manager);
        FileHandler.loadData();
        
    }
}


