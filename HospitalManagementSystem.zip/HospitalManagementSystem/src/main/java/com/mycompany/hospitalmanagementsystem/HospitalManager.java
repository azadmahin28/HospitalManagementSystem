/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;

/**
 *
 * @author Msi user
 */
import java.util.ArrayList;
import java.util.List;

public class HospitalManager {
    
    private final List<Doctor> doctors;
    private final List<Patient> patients;

    public HospitalManager() {
        doctors = new ArrayList<>();
        patients = new ArrayList<>();
    }

    public void addDoctor(Doctor d) { doctors.add(d); }
    public void addPatient(Patient p) { patients.add(p); }
    
    public void assignDoctor(int patientIndex, int doctorIndex) {
        if(patientIndex >= 0 && patientIndex < patients.size() && doctorIndex >= 0 && doctorIndex < doctors.size()) {
            System.out.println("Assigned " + doctors.get(doctorIndex).getName() + " to " + patients.get(patientIndex).getName());
        }
    }

    public List<Patient> getPatients() { return patients; }
    public List<Doctor> getDoctors() { return doctors; }
}
